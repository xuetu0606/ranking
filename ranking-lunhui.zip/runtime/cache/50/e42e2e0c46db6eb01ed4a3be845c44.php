<?php
//000000000000
 exit();?>
a:12:{s:14:"web_site_title";s:35:"2018 考研初试后台管理系统";s:20:"web_site_description";s:35:"2018 考研初试后台管理系统";s:16:"web_site_keyword";s:35:"2018 考研初试后台管理系统";s:12:"web_site_icp";s:0:"";s:13:"web_site_cnzz";s:0:"";s:13:"web_site_copy";s:69:"Copyright © 2018 考研初试后台管理系统 All rights reserved.";s:14:"web_site_close";s:1:"1";s:9:"list_rows";s:2:"10";s:14:"admin_allow_ip";N;s:13:"alisms_appkey";s:0:"";s:16:"alisms_appsecret";s:0:"";s:15:"alisms_signname";s:0:"";}